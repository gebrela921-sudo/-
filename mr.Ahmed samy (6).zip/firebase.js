import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";

import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

import { getStorage } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-storage.js";

const firebaseConfig = {

apiKey: "AIzaSyCu6aA1DImCb5ymUTRmtHuneSKhKt_OjZY",

authDomain: "mr-ahmed-samy.firebaseapp.com",

projectId: "mr-ahmed-samy",

storageBucket: "mr-ahmed-samy.firebasestorage.app",

messagingSenderId: "13532428225",

appId: "1:13532428225:web:b3074c1f0b3f67a0b2e140"

};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);

export const db = getFirestore(app);

export const storage = getStorage(app);firebase.js