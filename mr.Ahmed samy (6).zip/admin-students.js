import { db } from "./firebase.js";

import {
collection,
getDocs,
doc,
updateDoc,
deleteDoc
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

const studentsList = document.getElementById("studentsList");
const popup = document.getElementById("studentPopup");
const closePopup = document.getElementById("closePopup");
const saveStudent = document.getElementById("saveStudent");
const searchStudent = document.getElementById("searchStudent");

let currentStudentId = null;

closePopup.onclick = () => {

popup.style.display = "none";

};

async function loadStudents(){

studentsList.innerHTML = "";

const snapshot = await getDocs(collection(db,"users"));

snapshot.forEach((student)=>{

const data = student.data();

studentsList.innerHTML += `

<div class="admin-course-card">

<img src="images/user.png">

<div class="course-info">

<h3>${data.fullName}</h3>

<p>${data.studentCode}</p>

<span class="price">${data.wallet || 0} جنيه</span>

</div>

<div class="course-actions">

<button class="edit-btn" data-id="${student.id}">
✏️ تعديل
</button>

<button class="delete-btn" data-id="${student.id}">
🗑 حذف
</button>

</div>

</div>

`;

});

document.querySelectorAll(".edit-btn").forEach(btn=>{

btn.onclick = async()=>{

currentStudentId = btn.dataset.id;

const card = btn.closest(".admin-course-card");

document.getElementById("studentName").value =
card.querySelector("h3").textContent;

document.getElementById("studentCode").value =
card.querySelector("p").textContent;

document.getElementById("studentWallet").value =
card.querySelector(".price").textContent.replace(" جنيه","");

popup.style.display = "flex";

};

});

document.querySelectorAll(".delete-btn").forEach(btn=>{

btn.onclick = async()=>{

if(confirm("هل تريد حذف الطالب؟")){

await deleteDoc(doc(db,"users",btn.dataset.id));

loadStudents();

}

};

});

}

loadStudents();

saveStudent.onclick = async()=>{

try{

await updateDoc(doc(db,"users",currentStudentId),{

fullName:document.getElementById("studentName").value,

studentCode:document.getElementById("studentCode").value,

phone:document.getElementById("studentPhone").value,

parentPhone:document.getElementById("parentPhone").value,

grade:document.getElementById("studentGrade").value,

wallet:Number(document.getElementById("studentWallet").value)

});

popup.style.display="none";

alert("تم حفظ البيانات");

loadStudents();

}catch(error){

console.error(error);

alert("حدث خطأ");

}

};

searchStudent.onkeyup = ()=>{

const value = searchStudent.value.toLowerCase();

document.querySelectorAll(".admin-course-card").forEach(card=>{

const name = card.querySelector("h3").textContent.toLowerCase();

const code = card.querySelector("p").textContent.toLowerCase();

card.style.display =
name.includes(value) || code.includes(value)
? "block"
: "none";

});

};