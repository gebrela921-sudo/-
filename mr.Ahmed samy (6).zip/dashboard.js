import { auth, db } from "./firebase.js";

import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

import {
  doc,
  getDoc,
  collection,
  getDocs
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

onAuthStateChanged(auth, async (user) => {

    if (!user) {
        window.location.href = "login.html";
        return;
    }

    // بيانات الطالب
    const userRef = doc(db, "users", user.uid);
    const userSnap = await getDoc(userRef);

    if (userSnap.exists()) {

        const data = userSnap.data();

        document.getElementById("studentName").textContent =
            "أهلاً " + data.fullName;

        document.getElementById("studentCode").textContent =
            "كود الطالب: " + data.studentCode;

        document.getElementById("studentGrade").textContent =
            data.grade;

        document.getElementById("walletBalance").textContent =
            data.wallet + " جنيه";
    }

    // تحميل الكورسات
    const container = document.getElementById("coursesContainer");

    const querySnapshot = await getDocs(collection(db, "courses"));

    container.innerHTML = "";

    querySnapshot.forEach((docSnap) => {

        const course = docSnap.data();

        container.innerHTML += `
        <div class="course-card">

            <img src="${course.image}" class="course-image">

            <h3>${course.title}</h3>

            <p>${course.description}</p>

            <span class="price">
                ${course.price} جنيه
            </span>

            <a href="course.html?id=${docSnap.id}" class="course-btn">
                الدخول للكورس
            </a>

        </div>
        `;

    });

});