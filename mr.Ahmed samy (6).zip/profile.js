import { auth, db } from "./firebase.js";

import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

import {
  doc,
  getDoc
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

onAuthStateChanged(auth, async (user) => {

    if (!user) {

        window.location.href = "login.html";
        return;

    }

    try {

        const docRef = doc(db, "users", user.uid);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {

            const data = docSnap.data();

            document.getElementById("profileName").textContent = data.fullName;
            document.getElementById("profileCode").textContent = data.studentCode;
            document.getElementById("profileGrade").textContent = data.grade;

            document.getElementById("profileFullName").value = data.fullName;
            document.getElementById("profilePhone").value = data.phone;
            document.getElementById("profileParentPhone").value = data.parentPhone;
            document.getElementById("profileGovernorate").value = data.governorate;
            document.getElementById("profileGradeInput").value = data.grade;

        } else {

            alert("لم يتم العثور على بيانات الطالب");

        }

    } catch (error) {

        console.error(error);
        alert("حدث خطأ أثناء تحميل البيانات");

    }

});