const result = document.getElementById("attendanceResult");

document.querySelectorAll(".login-btn")[1].onclick = function(){

const code = document.getElementById("studentCode").value;

if(code===""){

alert("اكتب كود الطالب");

return;

}

result.innerHTML = `
✅ تم تسجيل حضور الطالب<br>
الكود: ${code}<br>
التاريخ: ${new Date().toLocaleDateString()}<br>
الوقت: ${new Date().toLocaleTimeString()}
`;

}