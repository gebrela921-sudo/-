import { db } from "./firebase.js";

import {
doc,
getDoc,
collection,
getDocs,
query,
where
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

/* ---------- Tabs ---------- */

const tabs = document.querySelectorAll(".tab");
const contents = document.querySelectorAll(".tab-content");

tabs.forEach(tab=>{

tab.onclick=()=>{

tabs.forEach(t=>t.classList.remove("active"));
contents.forEach(c=>c.classList.remove("active"));

tab.classList.add("active");

document
.getElementById(tab.dataset.tab)
.classList.add("active");

};

});

/* ---------- Course ---------- */

const params = new URLSearchParams(window.location.search);

const courseId = params.get("id");

async function loadCourse(){

if(!courseId) return;

const courseRef = doc(db,"courses",courseId);

const courseSnap = await getDoc(courseRef);

if(courseSnap.exists()){

const course = courseSnap.data();

document.getElementById("courseTitle").textContent =
course.title;

document.getElementById("courseDescription").textContent =
course.description;

}

loadLessons();

loadExams();

}

/* ---------- Lessons ---------- */

async function loadLessons(){

const videosContainer =
document.getElementById("videosContainer");

const pdfContainer =
document.getElementById("pdfContainer");

videosContainer.innerHTML="";
pdfContainer.innerHTML="";

const q = query(
collection(db,"lessons"),
where("courseId","==",courseId)
);

const snapshot = await getDocs(q);

snapshot.forEach(item=>{

const lesson = item.data();

videosContainer.innerHTML += `

<div class="video-card">

<h3>${lesson.title}</h3>

<video controls>

<source src="${lesson.video}" type="video/mp4">

</video>

</div>

`;

pdfContainer.innerHTML += `

<div class="pdf-card">

<h3>${lesson.title}</h3>

<a href="${lesson.pdf}" target="_blank" class="pdf-btn">

فتح الملف

</a>

</div>

`;

});

}

/* ---------- Exams ---------- */

async function loadExams(){

const examContainer =
document.getElementById("examContainer");

examContainer.innerHTML="";

const q = query(
collection(db,"exams"),
where("courseId","==",courseId)
);

const snapshot = await getDocs(q);

snapshot.forEach(item=>{

const exam = item.data();

examContainer.innerHTML += `

<div class="exam-card">

<h3>${exam.title}</h3>

<p>${exam.questions} سؤال</p>

<a href="exam.html?id=${item.id}" class="exam-btn">

ابدأ الامتحان

</a>

</div>

`;

});

}

loadCourse();