import { auth } from "./firebase.js";

import {
  signOut
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

const logoutBtn = document.getElementById("logoutBtn");

logoutBtn.addEventListener("click", async (e) => {

    e.preventDefault();

    try{

        await signOut(auth);

        window.location.href = "login.html";

    }catch(error){

        alert("حدث خطأ أثناء تسجيل الخروج");

    }

});