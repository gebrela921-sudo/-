import { auth } from "./firebase.js";

import {
  signInWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

const password = document.getElementById("password");
const showPassword = document.getElementById("showPassword");

showPassword.addEventListener("click", () => {

    if(password.type === "password"){

        password.type = "text";
        showPassword.innerHTML = "🙈";

    }else{

        password.type = "password";
        showPassword.innerHTML = "👁";

    }

});

const form = document.querySelector("form");

form.addEventListener("submit", async (e) => {

    e.preventDefault();

    const phone = document.querySelector('input[type="tel"]').value;
    const passwordValue = password.value;

    const email = phone + "@student.mrahmedsamy.com";

    try{

        await signInWithEmailAndPassword(
            auth,
            email,
            passwordValue
        );

        alert("تم تسجيل الدخول بنجاح");

        window.location.href = "dashboard.html";

    }catch(error){

        alert("رقم الهاتف أو كلمة المرور غير صحيحة");

    }

})
