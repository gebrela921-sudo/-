import { auth, db } from "./firebase.js";

import {
  createUserWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

import {
  doc,
  setDoc
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

const registerForm = document.getElementById("registerForm");

registerForm.addEventListener("submit", async (e) => {

  e.preventDefault();

  const fullName = document.getElementById("fullName").value;
  const phone = document.getElementById("phone").value;
  const parentPhone = document.getElementById("parentPhone").value;
  const governorate = document.getElementById("governorate").value;
  const grade = document.getElementById("grade").value;
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;

  if (password !== confirmPassword) {
    alert("كلمة المرور غير متطابقة");
    return;
  }

  // تحويل رقم الهاتف إلى بريد إلكتروني داخلي
  const email = phone + "@student.mrahmedsamy.com";
// إنشاء كود الطالب
const studentCode = "2" + Math.floor(1000 + Math.random() * 9000);
  try {

    const userCredential = await createUserWithEmailAndPassword(
      auth,
      email,
      password
    );

await setDoc(doc(db, "users", userCredential.user.uid), {
  fullName,
  phone,
  parentPhone,
  governorate,
  grade,
  wallet: 0,
  studentCode: studentCode,
  role: "student",
centerId: "",
groupId: "",
attendance: 0,
subscriptionStatus: "inactive",
  createdAt: new Date()
});
    alert("تم إنشاء الحساب بنجاح");

    window.location.href = "dashboard.html";

  } catch (error) {

    alert(error.message);

  }

});