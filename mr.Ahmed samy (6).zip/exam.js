let time = 20 * 60;

const timer = document.getElementById("timer");

const examForm = document.getElementById("examForm");

const countdown = setInterval(()=>{

let minutes = Math.floor(time / 60);

let seconds = time % 60;

timer.innerHTML =
`${minutes}:${seconds.toString().padStart(2,"0")}`;

time--;

if(time < 0){

clearInterval(countdown);

alert("انتهى وقت الامتحان");

examForm.submit();

}

},1000);

examForm.addEventListener("submit",function(e){

e.preventDefault();

let score = 0;

document
.querySelectorAll("input[type=radio]:checked")
.forEach(answer=>{

score += Number(answer.value);

});

alert(`درجتك هي ${score} من 2`);

});