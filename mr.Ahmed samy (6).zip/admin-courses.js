import { db } from "./firebase.js";

import {
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  updateDoc,
  doc
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

console.log("admin-courses.js Loaded");

const addBtn = document.getElementById("addCourseBtn");
const popup = document.getElementById("coursePopup");
const closeBtn = document.getElementById("closePopup");
const saveBtn = document.getElementById("saveCourse");
const coursesList = document.getElementById("coursesList");
const searchInput = document.getElementById("searchCourse");

let editId = null;

// فتح نافذة إضافة كورس
addBtn.onclick = () => {

    editId = null;

    document.getElementById("courseTitle").value = "";
    document.getElementById("courseDescription").value = "";
    document.getElementById("coursePrice").value = "";
    document.getElementById("courseImage").value = "";

    popup.style.display = "flex";

};

// غلق النافذة
closeBtn.onclick = () => {

    popup.style.display = "none";

};

// تحميل الكورسات
async function loadCourses() {

    coursesList.innerHTML = "";

    const snapshot = await getDocs(collection(db, "courses"));

    snapshot.forEach((course) => {

        const data = course.data();

        coursesList.innerHTML += `

        <div class="admin-course-card">

            <img src="${data.image}" alt="">

            <div class="course-info">

                <h3>${data.title}</h3>

                <p>${data.grade}</p>

                <span class="price">${data.price} جنيه</span>

            </div>

            <div class="course-actions">

                <button class="edit-btn" data-id="${course.id}">
                    ✏️ تعديل
                </button>

                <button class="delete-btn" data-id="${course.id}">
                    🗑 حذف
                </button>

            </div>

        </div>

        `;

    });
        // أزرار الحذف
    document.querySelectorAll(".delete-btn").forEach(btn => {

        btn.onclick = async () => {

            if (confirm("هل تريد حذف الكورس؟")) {

                try {

                    await deleteDoc(doc(db, "courses", btn.dataset.id));

                    alert("تم حذف الكورس");

                    loadCourses();

                } catch (error) {

                    console.error(error);

                    alert("حدث خطأ أثناء الحذف");

                }

            }

        };

    });

    // أزرار التعديل
    document.querySelectorAll(".edit-btn").forEach(btn => {

        btn.onclick = () => {

            editId = btn.dataset.id;

            const card = btn.closest(".admin-course-card");

            document.getElementById("courseTitle").value =
                card.querySelector("h3").textContent;

            document.getElementById("courseGrade").value =
                card.querySelector("p").textContent;

            document.getElementById("coursePrice").value =
                card.querySelector(".price").textContent.replace(" جنيه", "");

            document.getElementById("courseDescription").value = "";

            document.getElementById("courseImage").value =
                card.querySelector("img").src;

            popup.style.display = "flex";

        };

    });

}

// تشغيل الصفحة
loadCourses();

// حفظ أو تعديل
saveBtn.onclick = async () => {

    const data = {

        title: document.getElementById("courseTitle").value,
        description: document.getElementById("courseDescription").value,
        grade: document.getElementById("courseGrade").value,
        price: Number(document.getElementById("coursePrice").value),
        image: document.getElementById("courseImage").value,
        locked: false

    };

    try {

        if (editId) {

            await updateDoc(doc(db, "courses", editId), data);

            alert("تم تعديل الكورس");

        } else {

            await addDoc(collection(db, "courses"), data);

            alert("تم إضافة الكورس");

        }

        popup.style.display = "none";

        editId = null;

        document.getElementById("courseTitle").value = "";
        document.getElementById("courseDescription").value = "";
        document.getElementById("coursePrice").value = "";
        document.getElementById("courseImage").value = "";

        loadCourses();

    } catch (error) {

        console.error(error);

        alert("حدث خطأ");

    }

};

// البحث
searchInput.addEventListener("input", () => {

    const value = searchInput.value.toLowerCase();

    document.querySelectorAll(".admin-course-card").forEach(card => {

        const title = card.querySelector("h3").textContent.toLowerCase();

        card.style.display = title.includes(value) ? "block" : "none";

    });

});